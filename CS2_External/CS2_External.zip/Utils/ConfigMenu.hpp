#pragma once

namespace ConfigMenu {
    void RenderConfigMenu();
    void ResetToDefault();
    // Define other configuration-related functions and variables here.
}
